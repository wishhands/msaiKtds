pip install streamlit
pip install openai python-dotenv
python -m streamlit run 05.open_chtbot.py --server.port 8000 --server.address 0.0.0.0