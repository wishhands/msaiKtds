import streamlit as st
from PIL import Image, ImageDraw, ImageFont
from azure.ai.documentintelligence import DocumentIntelligenceClient
from azure.ai.documentintelligence.models import AnalyzeDocumentRequest
from azure.ai.vision.imageanalysis import ImageAnalysisClient
from azure.ai.vision.imageanalysis.models import VisualFeatures
from azure.core.credentials import AzureKeyCredential


# Azure 설정
#AZURE_ENDPOINT = "https://msai0812-ai-01.cognitiveservices.azure.com/"
#AZURE_KEY = "1oRC29daSvJEjNunII1r2PQssKSuwagUvUUKGplSqthGC5vwU21DJQQJ99BHACMsfrFXJ3w3AAAEACOGDGQ2"
AZURE_ENDPOINT = "https://winkey-ai-130.cognitiveservices.azure.com/"
AZURE_KEY = "AGV2ewxAecjrPsRWl79hrqf2kFb8i7JvCT5k2xCiYqoTvo7UEQIKJQQJ99BHACYeBjFXJ3w3AAAEACOG3JwP"


credential=AzureKeyCredential(AZURE_KEY)

client = ImageAnalysisClient(endpoint=AZURE_ENDPOINT,
                            credential=credential)

image_path = "C:/Users/User/Downloads/msai0812/sample_images/catdog.jpg"

def get_image_info():
    #file_path = input("Enter the path to the image file : ")
    #image_path = "C:/Users/User/Downloads/msai0812/sample_images/catdog.jpg"
        
    with open(image_path,"rb") as image_file:
        image_data = image_file.read()
    
    result = client.analyze(
                image_data=image_data,
                visual_features=[
                    VisualFeatures.TAGS,
                    VisualFeatures.CAPTION,
                    VisualFeatures.OBJECTS
                ],
                model_version="latest"
            )
    
    print(result)
    if result.caption is not None:
        print(" Caption: ")
        print(f" '{result.caption.text}, confidence: {result.caption.confidence:.4f}")

    if result.tags is not None:
        print(" Tags: ")
        for tag in result.tags.list:
            print(f" '{tag.name}, confidence: {tag.confidence:.4f}")

    if result.objects is not None:
        print(" Objects: ")
        obj_name = []
        bounding_boxes = []
        
        for obj in result.objects.list:
            print(f" '{obj.tags[0].name}, {obj.bounding_box}, confidence: {obj.tags[0].confidence:.4f}")
            bounding_boxes.append(obj.bounding_box)
            obj_name.append(obj.tags[0].name)
            
        draw_bounding_boxes(image_path, bounding_boxes, obj_name)


def draw_bounding_boxes(image_path, bounding_boxes, obj_name):
    image = Image.open(image_path)
    draw = ImageDraw.Draw(image)
    
    for index, box in enumerate(bounding_boxes):
        x = box['x']
        y = box['y']
        w = box['w']
        h = box['h']
        
        draw.rectangle(((x,y),(x+w,y+h)),outline="red",width=2)
        draw.text((x,y),obj_name[index],fill="red")

    image.show()


if __name__=="__main__":
    get_image_info()